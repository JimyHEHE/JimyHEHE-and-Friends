<!DOCTYPE html>
<html>
<head>
	<title>SEMINAR</title>
</head>
<body>
	<div id="container">
		<div id="header">
			<center>
				<img src="banner1.jpg" alt="banner">
			</center>
		</div>
		<div id="content">
			<center>
				<h2>SEMINAR INFO</h2>
			</center>
			<center>
				<table border="0" cellpadding="5" cellspacing="1" bgcolor="white" style="padding: 20px; border-top: 1px solid black; border-left: 2px solid black; border-right: 2px solid black; border-bottom: 1px solid black; border-radius: 10px">
					<tr>
						<td>TAJUK</td>
						<td>:</td>
						<td>SEMINAR BAGAIMANA MENJANA RM8000 SEBULAN DI SHOPEE</td>
					</tr>
					<tr>
						<td>PENCERAMAH</td>
						<td>:</td>
						<td>TUAN RAHMAN BASRI</td>
					</tr>
					<tr>
						<td>SLOT</td>
						<td>:</td>
						<td>- 24 JUN 2021, 10 AM</td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td>- 30 JUN 2021, 10 AM</td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td>- 1 JULAI 2021, 10 AM</td>
					</tr>
					<tr>
						<td>HARGA</td>
						<td>:</td>
						<td>RM 69</td>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td>
							<button onclick="document.location='register.php'">Daftar</button>
							<button onclick="document.location='akaun.php'">Akaun</button>
						</td>
					</tr>
				</table>
			</center>
		</div>
	</div>
</body>
</html>