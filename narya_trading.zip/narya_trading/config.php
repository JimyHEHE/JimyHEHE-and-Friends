<?php 
$link = mysqli_connect("localhost","root","","narya_trading");
 ?>